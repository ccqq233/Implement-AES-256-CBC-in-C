Attention: When encrypting and decrypting files, the output file name should be different from the input file, otherwise it will result in inability to encrypt and decrypt and damage to the original file.

Before use:
1. Confirm that the OpenSSL development library has been installed correctly.
2. Ensure that the header file path is configured correctly.

The security of this program comes from:
1. Secure key generation mechanism and strict key management mechanism:
(1) This program generates unpredictable random bytes as keys using OpenSSL's cryptographic secure pseudo-random number generator (CSPRNG), meeting the requirements of unpredictability and no statistical bias. The RAND_priv-bytes() function in the code is dedicated to generating sensitive data and is isolated from the ordinary random number interface RAND-bytes () to avoid side channel attacks caused by resource competition.
(2) Before generating the key, the program will ensure that the random number generator has sufficient entropy to generate cryptographic secure random numbers.
(3) When exiting the program, the memory area where the key is stored will be securely overwritten to ensure that the key does not remain in memory for recovery or theft.

2. The security of AES-256 algorithm itself:
(1) After nearly 20 years of public analysis and attack attempts by top cryptographers around the world, the AES algorithm has yet to discover any effective mathematical vulnerabilities that can significantly outperform brute force cracking. Its design is based on a solid mathematical foundation (operations on finite fields).
(2) The key space of this algorithm is quite large, with a 256 bit key meaning there are approximately 1.1579x10 ^ 77 possible keys. Even with the most powerful supercomputers currently available for brute force cracking, the time required far exceeds the age of the universe.
(3) AES has strong resistance to various known cryptanalysis attacks, such as differential cryptanalysis, linear cryptanalysis, integral attacks, etc., especially when the number of rounds is sufficient (AES-256 has 14 rounds). The complexity of these attacks is still much higher than brute force cracking.

3. CBC mode XORing the previous ciphertext block with the current plaintext block before encrypting, which brings key benefits:
(1) Semantic security: Even if identical plaintext blocks appear in different positions of the message (or even in different messages), as long as the initialization vector IV is random and unique, and the previous ciphertext block is different, they will be encrypted into completely different ciphertext blocks, which hides the statistical patterns and repetitive structures of the plaintext. In other words, assuming there is no CBC mode, the same plaintext block will be encrypted into the same ciphertext block, which will expose the pattern of the data (for example, large areas of the same color in an image still have similar features after encryption, with low security).
(2) Diffusion: A change in one plaintext or IV bit during the encryption process can cause unpredictable changes to all subsequent ciphertext blocks (avalanche effect), making it difficult for attackers to intentionally tamper with the ciphertext or predict the result.
(3) Random and unique IV is the key to the safety of CBC: even if the same message is encrypted multiple times, as long as the IV is different, the resulting ciphertext is completely different, preventing attackers from inferring the similarity or content of plaintext by comparing ciphertexts.


注意：對檔案進行加密或解密時，輸出檔案名稱應與輸入檔案不同，否則會導致無法執行加解密操作並損毀原始檔案。

使用前：
1、確認 OpenSSL 開發庫已正確安裝。
2、確保標頭檔案路徑配置正確。

本程式安全性源自：
1. 安全的金鑰生成機制與嚴格的金鑰管理機制：
(1) 本程式透過 OpenSSL 的 密碼學安全僞隨機數生成器（CSPRNG） 生成不可預測的隨機位元組作為金鑰，符合不可預測性、無統計偏差的要求。程式碼中 RAND_priv_bytes() 函數專用於生成敏感資料，與普通隨機數接口 RAND_bytes() 隔離，避免資源競爭導致的旁路攻擊。
(2) 生成金鑰前程式將確保隨機數生成器具備足夠熵值，以生成密碼學安全的隨機數。
(3) 程式結束時將徹底覆寫儲存金鑰的記憶體區域，確保金鑰不會殘留於記憶體中被復原或竊取。

2. AES-256 演算法本身的安全性：
(1) AES 演算法經全球頂尖密碼學家長達近20年的公開分析與攻擊測試，至今未發現任何能顯著優於暴力破解法的有效數學漏洞。其設計基於嚴謹的數學基礎（有限域運算）。
(2) 該演算法的金鑰空間極龐大，256位元金鑰意味著存在約1.1579×10⁷⁷個可能金鑰。即使動用當今最強超級電腦進行暴力破解，所需時間亦遠超宇宙年齡。
(3) AES 對各類已知密碼分析攻擊（如差分密碼分析、線性密碼分析、積分攻擊等）具極強抵抗性，尤其在充足輪數下（AES-256為14輪）。此類攻擊複雜度仍遠高於暴力破解法。

3. CBC模式將前一個密文區塊與當前明文區塊進行 XOR 運算後再加密，此機制帶來關鍵優勢：
(1) 語義安全性：即使完全相同的明文區塊出現在訊息不同位置（或不同訊息中），只要初始化向量IV具隨機性且唯一，且前序密文區塊不同，這些明文區塊將被加密成完全相異的密文區塊，從而隱藏明文的統計模式與重複結構。換言之，假設沒有CBC模式，相同明文區塊會產生相同密文區塊，將暴露數據模式（例如圖片中大片同色區域加密後仍保留相似特徵，安全性極低）。
(2) 擴散性：加密過程中單個明文物件或IV位元的變更，將導致後續所有密文區塊產生不可預測的變化（雪崩效應），使攻擊者難以透過篡改密文進行針對性破壞或結果預測。
(3) 隨機且唯一的IV是CBC的安全性的關鍵：即使重複加密相同訊息，只要IV不同，產生的密文即完全不同，可防止攻擊者透過比對密文推斷明文相似性或內容。